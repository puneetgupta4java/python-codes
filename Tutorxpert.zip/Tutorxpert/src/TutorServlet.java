import java.io.IOException;
import java.io.PrintWriter;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.sql.Connection;


/**
 * Servlet implementation class SignupServlet
 */
@WebServlet("/Tutor")
public class TutorServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
	
        String name = request.getParameter("name");
        String age = request.getParameter("age");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String phone = request.getParameter("phone");
        String fees = request.getParameter("fees");
        String add = request.getParameter("address");
        String city = request.getParameter("city");
        String exp = request.getParameter("exp");
        String timing = request.getParameter("timing");
        String field = request.getParameter("type");
        
        try{
        
        //loading drivers for mysql
        Class.forName("com.mysql.jdbc.Driver");

	//creating connection with the database 
          Connection  con=DriverManager.getConnection
                     ("jdbc:mysql://localhost:3306/tutorxpert","root","root");

        PreparedStatement ps=con.prepareStatement
                  ("insert into tutor values(?,?,?,?,?,?,?,?,?,?);");

        ps.setString(1, name);
        ps.setInt(2, Integer.parseInt(age));
        ps.setString(3, email);
        ps.setInt(4, Integer.parseInt(phone));
        ps.setInt(5, Integer.parseInt(exp));
        ps.setString(6, field);
        ps.setString(7, add);
        ps.setString(8, password);
        ps.setString(9, timing);
		ps.setInt(10, Integer.parseInt(fees));
        ps.setString(11, city);
        
        int i=ps.executeUpdate();
        
          if(i>0)
          {
           response.sendRedirect("index.jsp");
          }
		  else{
			  response.sendRedirect("Signuptutor.jsp");
		  }
        
        }
        catch(Exception se)
        {
            se.printStackTrace();
        }
	
      }
  }