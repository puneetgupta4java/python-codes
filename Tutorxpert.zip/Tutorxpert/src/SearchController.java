import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "SearchController", urlPatterns = {"/SearchController"})
public class SearchController extends HttpServlet {

   
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
            String type = request.getParameter("type");
            String location = request.getParameter("location");
            ArrayList<String> a = new ArrayList<String>();
        try {
            System.out.print(type + location);
            Connection con = ConnectDb.getConnection();
            PreparedStatement psmt = con.prepareStatement("select name from tutor where field=? and city=?;");
            psmt.setString(1, type);
            psmt.setString(2, location);
            System.out.print(psmt);
            ResultSet rs = psmt.executeQuery();
            while(rs.next()){
               a.add(rs.getString("name"));
            }
            for(String d : a){
                System.out.println(d);
            }
            HttpSession session1 = request.getSession(true);
            session1.setAttribute("list", a);
            response.sendRedirect("ShowTutor.jsp");
        } catch (Exception ex) {
            ex.printStackTrace();
            response.sendRedirect("errorpage.html");
        }
            
      
    }
    
}
